# Cybersecurity Awareness Chatbot

A cybersecurity awareness assistant for South African citizens, built across two parts as a C# .NET project.

---

## Project Structure

```
CyberbotProject/
├── Cyberbot/           ← Part 1: Console application (fixed)
└── CyberbotGUI/        ← Part 2: WPF GUI application
```

---

## Part 1 — Console Application (Fixed)

### What was fixed
- Added `exit` / `quit` / `bye` command to end the session gracefully
- `VoiceAssistant` now uses `SpeakAsync` (non-blocking) and has proper try/catch
- `AudioPlayer` uses `Play()` instead of `PlaySync()` so it doesn't freeze the app
- `Chatbot` expanded with 8 intents: password, phishing, privacy, malware, VPN, 2FA, browsing, social engineering
- Memory now stores display names (e.g. "Password Safety") instead of internal keys
- Added typing effect via `UIHelper.TypeWrite()`
- Improved ASCII art logo using box-drawing characters

### How to run (Part 1)
```
cd Cyberbot
dotnet run
```

**Requirements:** Windows, .NET 8 SDK

---

## Part 2 — WPF GUI Application

### Features implemented

| Requirement | Implementation |
|---|---|
| GUI with WPF | `MainWindow.xaml` — dark cybersecurity-themed chat interface |
| Voice greeting | `AudioPlayer.PlayGreeting()` plays `greeting.wav` on startup |
| ASCII art logo | Displayed in the header using Consolas monospace font |
| Keyword recognition | 8 cybersecurity intents with multiple keywords each |
| Random responses | Each intent has 5 responses, one randomly selected per query |
| Conversation flow | Follow-up phrases like "tell me more", "another tip", "explain" work seamlessly |
| Memory & recall | Sidebar shows user name, favourite topic, and all topics discussed |
| Sentiment detection | Detects: worried, curious, frustrated, confused, happy — shows coloured banner and adjusts response tone |
| Error handling | Default fallback for unknown inputs; no crashes on unexpected input |
| Code optimisation | Classes, services, models, helpers — fully separated by responsibility |

### How to run (Part 2)
```
cd CyberbotGUI
dotnet run
```

**Requirements:** Windows, .NET 8 SDK

### GUI Layout
- **Header** — ASCII logo, title, user name, online indicator
- **Chat area** — Scrollable chat bubbles (bot on left, user on right)
- **Sentiment bar** — Colour-coded banner showing detected emotion (dismissable)
- **Memory sidebar** — Shows user name, favourite topic, and all discussed topics
- **Quick Topics panel** — One-click buttons for all 8 cybersecurity topics
- **Input area** — Text box with placeholder, voice toggle, and Send button

### Voice toggle
Click the 🔊 button in the input area to enable/disable text-to-speech for bot responses.

---

## GitHub CI Workflow
A `.github/workflows/build.yml` workflow is included. It builds the project on every push to verify there are no build errors.

---

## Topics Covered
1. 🔐 Password Safety
2. 🎣 Phishing & Scams
3. 🕵️ Online Privacy
4. 🦠 Malware & Viruses
5. 🌐 VPN & Secure Connections
6. 🔑 Two-Factor Authentication
7. 🖥️ Safe Browsing
8. 🎭 Social Engineering
