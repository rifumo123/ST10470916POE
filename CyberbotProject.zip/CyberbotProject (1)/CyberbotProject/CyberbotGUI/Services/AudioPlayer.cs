using System;
using System.IO;
using System.Media;

namespace CyberbotGUI.Services
{
    public static class AudioPlayer
    {
        public static void PlayGreeting()
        {
            try
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "greeting.wav");
                if (!File.Exists(path)) return;

                using var player = new SoundPlayer(path);
                player.Play(); // Non-blocking — doesn't freeze the UI
            }
            catch
            {
                // Silently skip if audio not available
            }
        }
    }
}
