using System;
using System.Collections.Generic;
using System.Linq;
using CyberbotGUI.Models;

namespace CyberbotGUI.Services
{
    public class Chatbot
    {
        // ── Memory properties ────────────────────────────────────────
        public string UserName { get; set; } = "";
        public string FavouriteTopic { get; private set; } = "";

        private readonly List<string> _topicsDiscussed = new();
        private string _lastIntent = "";

        private readonly List<Intent> _intents;
        private readonly Random _random = new();

        public IReadOnlyList<string> TopicsDiscussed => _topicsDiscussed.AsReadOnly();

        // ── Constructor ───────────────────────────────────────────────
        public Chatbot()
        {
            _intents = new List<Intent>
            {
                new Intent
                {
                    Name = "password",
                    DisplayName = "Password Safety",
                    Keywords = new() { "password", "login", "credentials", "passphrase", "pin", "account security" },
                    Responses = new()
                    {
                        "Use strong, unique passwords for every account — aim for at least 12 characters.",
                        "Avoid reusing passwords across sites. If one is breached, all accounts using it are at risk.",
                        "A password manager like Bitwarden or 1Password stores your passwords securely so you only need one master password.",
                        "Try passphrases — four or five random words strung together are hard to crack and easy to remember.",
                        "Never share your password via email, phone, or any chat application, even if the requester seems legitimate."
                    },
                    DetailResponse = "Strong passwords should be at least 12 characters and combine uppercase letters, lowercase letters, numbers, and special symbols like !@#$. Avoid personal details such as birthdays or your pet's name — these are easy to guess."
                },
                new Intent
                {
                    Name = "phishing",
                    DisplayName = "Phishing & Scams",
                    Keywords = new() { "phishing", "email scam", "fake email", "scam", "spam", "fraud", "suspicious email", "fake link" },
                    Responses = new()
                    {
                        "Phishing emails mimic trusted companies to trick you into handing over personal information.",
                        "Be suspicious of emails creating urgency — 'Your account will be closed in 24 hours!' is a classic tactic.",
                        "Always hover over links before clicking to check the real destination URL.",
                        "Scammers often impersonate banks, SARS, and government agencies — verify any such contact directly.",
                        "When in doubt, contact the organisation through their official website — never use numbers or links in a suspicious email."
                    },
                    DetailResponse = "Phishing red flags: generic greetings ('Dear Customer'), spelling mistakes, unusual sender addresses, requests for sensitive info, and URLs that don't quite match the real domain (e.g. 'amaz0n.com' instead of 'amazon.com')."
                },
                new Intent
                {
                    Name = "privacy",
                    DisplayName = "Online Privacy",
                    Keywords = new() { "privacy", "private", "personal data", "data", "tracking", "surveillance", "information sharing" },
                    Responses = new()
                    {
                        "Review privacy settings on all your social media accounts — most default to sharing too much.",
                        "Limit the personal information you post online. Your full birthday, home address, and phone number can be used for identity theft.",
                        "Use private or incognito browsing mode to reduce tracking while you browse.",
                        "Be careful what you share — once something is online, it's nearly impossible to fully remove.",
                        "Use encrypted messaging apps like Signal for private conversations."
                    },
                    DetailResponse = "Your digital footprint is everything you do online. Privacy-focused tools like the Brave browser, DuckDuckGo search engine, and the uBlock Origin extension can significantly reduce how much data companies collect about you."
                },
                new Intent
                {
                    Name = "malware",
                    DisplayName = "Malware & Viruses",
                    Keywords = new() { "malware", "virus", "ransomware", "spyware", "trojan", "infected", "worm", "keylogger" },
                    Responses = new()
                    {
                        "Malware is malicious software designed to steal your data, damage files, or lock you out of your system.",
                        "Keep your antivirus software updated — cybercriminals release new threats daily.",
                        "Ransomware encrypts all your files and demands payment to restore them. Regular backups are your best protection.",
                        "Only download software from official app stores or the developer's official website.",
                        "Spyware can silently monitor everything you do, including your keystrokes and webcam. A good antivirus can detect it."
                    },
                    DetailResponse = "South Africa is among the most targeted countries for ransomware attacks. Back up your data regularly — at minimum weekly — to an external drive or a cloud service. This way you can recover without paying any ransom."
                },
                new Intent
                {
                    Name = "vpn",
                    DisplayName = "VPN & Secure Connections",
                    Keywords = new() { "vpn", "public wifi", "public wi-fi", "network", "encrypt", "secure connection", "ip address" },
                    Responses = new()
                    {
                        "A VPN (Virtual Private Network) encrypts all your internet traffic, protecting you on public Wi-Fi.",
                        "Avoid banking or logging into accounts on public Wi-Fi without a VPN — your data could be intercepted.",
                        "Choose a reputable VPN — free VPNs often fund themselves by selling your browsing data to advertisers.",
                        "A VPN also hides your IP address, giving you greater anonymity and privacy online.",
                        "Always verify that websites use HTTPS — the padlock icon in your browser address bar — before entering any sensitive info."
                    },
                    DetailResponse = "On public Wi-Fi at airports or coffee shops, attackers on the same network can intercept unencrypted traffic (a 'man-in-the-middle' attack). A VPN creates an encrypted tunnel that makes your traffic unreadable to anyone snooping."
                },
                new Intent
                {
                    Name = "2fa",
                    DisplayName = "Two-Factor Authentication",
                    Keywords = new() { "two factor", "two-factor", "2fa", "mfa", "multi-factor", "authenticator", "verification code", "otp", "one-time" },
                    Responses = new()
                    {
                        "Two-Factor Authentication (2FA) adds a second layer of security — even if your password is stolen, attackers still can't get in.",
                        "Enable 2FA on all your important accounts: email, banking, social media, and cloud storage.",
                        "Use an authenticator app like Google Authenticator or Authy rather than SMS, which can be intercepted.",
                        "Hardware security keys (like YubiKey) are the most secure form of 2FA — great for high-value accounts.",
                        "Many high-profile account breaches could have been prevented if 2FA had been enabled."
                    },
                    DetailResponse = "SMS-based 2FA is a good start, but authenticator apps are better because SIM-swapping attacks can reroute your text messages. For the most critical accounts (email, banking), consider a physical hardware key for the strongest protection."
                },
                new Intent
                {
                    Name = "browsing",
                    DisplayName = "Safe Browsing",
                    Keywords = new() { "browsing", "browser", "website", "online", "internet", "chrome", "firefox", "https", "url", "link" },
                    Responses = new()
                    {
                        "Always check for HTTPS and the padlock icon before entering personal data on any website.",
                        "Keep your browser updated — updates patch known security vulnerabilities that hackers actively exploit.",
                        "Use an ad blocker like uBlock Origin to block malicious ads and reduce tracker data collection.",
                        "Avoid clicking pop-up ads — they often redirect to sites that silently install malware.",
                        "Be cautious when downloading files. Verify the source is legitimate and scan downloads with your antivirus."
                    },
                    DetailResponse = "A solid browser security setup includes: an ad blocker (uBlock Origin), automatic browser updates enabled, and avoiding saving passwords in your browser (use a password manager instead). Consider Brave or Firefox for built-in privacy protection."
                },
                new Intent
                {
                    Name = "social_engineering",
                    DisplayName = "Social Engineering",
                    Keywords = new() { "social engineering", "manipulation", "pretexting", "baiting", "impersonation", "trick", "deceive" },
                    Responses = new()
                    {
                        "Social engineering manipulates people psychologically into revealing confidential information.",
                        "Legitimate IT support staff will never ask for your password. If someone does, it's a scam.",
                        "Verify the identity of anyone requesting sensitive information — by calling them back on a known number.",
                        "Hackers can hijack email accounts and impersonate your colleagues — double-check unusual requests in person.",
                        "Social engineers create urgency to rush your decision. Slowing down and verifying is always the right move."
                    },
                    DetailResponse = "Common social engineering tactics: pretexting (fabricating a scenario to gain your trust), baiting (leaving infected USB drives in public places), and vishing (voice phishing calls from fake 'tech support' agents)."
                }
            };
        }

        // ── Core response method ──────────────────────────────────────
        public string GetResponse(string input, Sentiment sentiment = Sentiment.None)
        {
            string lower = input.ToLower();

            // Sentiment prefix for empathetic responses
            string prefix = BuildSentimentPrefix(sentiment);

            // Memory recall commands
            if (lower.Contains("what did we talk about") || lower.Contains("what have we discussed")
                || lower.Contains("what topics") || lower.Contains("recap"))
                return prefix + RecallMemory();

            if (lower.Contains("favourite") || lower.Contains("favorite")
                || lower.Contains("most interested") || lower.Contains("what do i like"))
                return prefix + RecallFavourite();

            if (lower.Contains("my name") || lower.Contains("who am i"))
                return string.IsNullOrEmpty(UserName)
                    ? "I don't know your name yet — please tell me!"
                    : $"Your name is {UserName}! I'll always remember it. 😊";

            // Follow-up / conversation flow
            bool isFollowUp = lower.Contains("tell me more") || lower.Contains("another tip")
                || lower.Contains("give me another") || lower.Contains("more detail")
                || lower.Contains("explain more") || lower.Contains("go on")
                || (lower.Contains("more") && lower.Length < 15)
                || (lower.Contains("explain") && lower.Length < 20);

            if (isFollowUp)
                return prefix + GetMoreDetails();

            // General / greeting queries
            if (lower.Contains("how are you") || lower.Contains("how do you do") || lower.Contains("are you okay"))
                return $"Running at full capacity and ready to help you stay safe online{NameTag()}! 💻";

            if (lower.Contains("what can you do") || lower.Contains("help me") || lower.Contains("what can i ask")
                || lower.Contains("topics") || lower.Contains("what do you know"))
                return $"I can help you with:\n\n🔐 Password Safety\n🎣 Phishing & Scams\n🕵️ Online Privacy\n🦠 Malware & Viruses\n🌐 VPN & Secure Connections\n🔑 Two-Factor Authentication\n🖥️ Safe Browsing\n🎭 Social Engineering\n\nWhat would you like to learn about{NameTag()}?";

            if (lower.Contains("hello") || lower.Contains("hi ") || lower == "hi" || lower.Contains("hey"))
                return $"Hello{NameTag()}! 👋 What cybersecurity topic can I help you with today?";

            if (lower.Contains("thank") || lower.Contains("thanks"))
                return $"You're very welcome{NameTag()}! Staying informed is one of the best defences against cyber threats. 🛡️";

            // Intent detection
            var bestIntent = DetectIntent(lower);
            if (bestIntent != null)
            {
                _lastIntent = bestIntent.Name;

                if (!_topicsDiscussed.Contains(bestIntent.DisplayName))
                    _topicsDiscussed.Add(bestIntent.DisplayName);

                if (string.IsNullOrEmpty(FavouriteTopic))
                    FavouriteTopic = bestIntent.DisplayName;

                return prefix + bestIntent.Responses[_random.Next(bestIntent.Responses.Count)];
            }

            return prefix + GetSmartFallback(lower);
        }

        // ── Private helpers ───────────────────────────────────────────

        private Intent? DetectIntent(string input)
        {
            Intent? bestMatch = null;
            int highestScore = 0;

            foreach (var intent in _intents)
            {
                int score = intent.Keywords.Count(k => input.Contains(k));
                if (score > highestScore)
                {
                    highestScore = score;
                    bestMatch = intent;
                }
            }

            return highestScore > 0 ? bestMatch : null;
        }

        private string GetMoreDetails()
        {
            if (string.IsNullOrEmpty(_lastIntent))
                return $"Which topic would you like more details on{NameTag()}? I cover passwords, phishing, privacy, malware, VPNs, 2FA, browsing, and social engineering.";

            var intent = _intents.FirstOrDefault(i => i.Name == _lastIntent);
            return intent?.DetailResponse
                ?? "Could you be more specific about what you'd like to know?";
        }

        private string RecallMemory()
        {
            if (_topicsDiscussed.Count == 0)
                return $"We haven't covered any cybersecurity topics yet{NameTag()}. Ask me about passwords, phishing, privacy, or more to get started!";

            string topics = string.Join(", ", _topicsDiscussed);
            return $"So far we've covered: {topics}.\nYour name is {UserName}" +
                   (string.IsNullOrEmpty(FavouriteTopic) ? "." : $" and your first topic of interest was {FavouriteTopic}.");
        }

        private string RecallFavourite()
        {
            if (string.IsNullOrEmpty(FavouriteTopic))
                return "We haven't discussed any topics yet! What are you most interested in?";

            return $"Based on our conversation, your favourite topic seems to be {FavouriteTopic}{NameTag()}. Would you like more detailed tips on that?";
        }

        private string BuildSentimentPrefix(Sentiment sentiment) => sentiment switch
        {
            Sentiment.Worried    => $"I understand you're feeling concerned, {UserName} — that's completely normal. Here's something that might help: ",
            Sentiment.Frustrated => "Let's simplify this. ",
            Sentiment.Confused   => "No worries — here it is more clearly: ",
            _                    => ""
        };

        private string GetSmartFallback(string input)
        {
            if (string.IsNullOrWhiteSpace(input) || input.Length < 2)
                return $"Please type your question{NameTag()} and I'll do my best to help!";

            if (input.Contains("?"))
                return $"That's a good question{NameTag()}! Try including a keyword like 'password', 'phishing', 'privacy', or 'malware' so I can give you the best answer.";

            return $"I'm not sure I understood that{NameTag()}. Try asking about: passwords, phishing, privacy, malware, VPNs, 2FA, or safe browsing.";
        }

        private string NameTag() => string.IsNullOrEmpty(UserName) ? "" : $", {UserName}";
    }
}
