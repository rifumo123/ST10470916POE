using System;
using System.Speech.Synthesis;

namespace CyberbotGUI.Services
{
    public static class VoiceAssistant
    {
        private static SpeechSynthesizer? _synth;
        private static bool _available = true;

        static VoiceAssistant()
        {
            try
            {
                _synth = new SpeechSynthesizer();
                _synth.SetOutputToDefaultAudioDevice();
                _synth.Rate = 0;
            }
            catch
            {
                _available = false;
            }
        }

        /// <summary>
        /// Asynchronously speaks the given text if voice is enabled and available.
        /// </summary>
        public static void Speak(string text)
        {
            if (!_available || _synth == null) return;

            try
            {
                _synth.SpeakAsyncCancelAll();
                _synth.SpeakAsync(text);
            }
            catch
            {
                _available = false;
            }
        }

        public static void StopSpeaking()
        {
            try { _synth?.SpeakAsyncCancelAll(); } catch { }
        }
    }
}
