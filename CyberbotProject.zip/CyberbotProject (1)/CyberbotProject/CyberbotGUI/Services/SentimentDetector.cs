using System.Collections.Generic;
using System.Linq;

namespace CyberbotGUI.Services
{
    public enum Sentiment { None, Worried, Curious, Frustrated, Confused, Happy }

    public static class SentimentDetector
    {
        private static readonly Dictionary<Sentiment, List<string>> Keywords = new()
        {
            [Sentiment.Worried] = new()
            {
                "worried", "scared", "nervous", "afraid", "anxious", "fear",
                "terrified", "panic", "stressed", "unsafe", "vulnerable"
            },
            [Sentiment.Curious] = new()
            {
                "curious", "interested", "wonder", "wondering", "want to know",
                "how does", "what is", "tell me", "can you explain", "fascinated"
            },
            [Sentiment.Frustrated] = new()
            {
                "frustrated", "angry", "annoyed", "hate", "fed up", "useless",
                "stupid", "terrible", "awful", "doesn't work", "can't believe"
            },
            [Sentiment.Confused] = new()
            {
                "confused", "lost", "don't understand", "not sure", "unclear",
                "what do you mean", "huh", "what?", "i'm confused", "makes no sense"
            },
            [Sentiment.Happy] = new()
            {
                "happy", "great", "awesome", "wonderful", "thanks", "thank you",
                "helpful", "love it", "amazing", "brilliant", "excellent"
            }
        };

        /// <summary>
        /// Detects the sentiment in the given input string.
        /// Returns the sentiment enum and a contextual acknowledgment message.
        /// </summary>
        public static (Sentiment Sentiment, string AcknowledgmentMessage) Detect(string input)
        {
            string lower = input.ToLower();

            foreach (var kvp in Keywords)
            {
                if (kvp.Value.Any(k => lower.Contains(k)))
                {
                    string message = kvp.Key switch
                    {
                        Sentiment.Worried =>
                            "I understand you're feeling worried — that's completely valid. Cybersecurity can feel overwhelming, but I'm here to help! 🛡️",
                        Sentiment.Curious =>
                            "I love the curiosity! 🔍 The best defence against cyber threats is exactly this kind of questioning mindset.",
                        Sentiment.Frustrated =>
                            "I hear your frustration. Let's work through this together — cybersecurity doesn't have to be complicated. 💪",
                        Sentiment.Confused =>
                            "No worries at all — let me explain this more clearly. There are no silly questions here! 😊",
                        Sentiment.Happy =>
                            "Great to hear that positive energy! 😊 Let's keep that momentum going.",
                        _ => ""
                    };
                    return (kvp.Key, message);
                }
            }

            return (Sentiment.None, "");
        }

        /// <summary>
        /// Returns a display emoji for the given sentiment.
        /// </summary>
        public static string GetEmoji(Sentiment sentiment) => sentiment switch
        {
            Sentiment.Worried    => "😟",
            Sentiment.Curious    => "🔍",
            Sentiment.Frustrated => "😤",
            Sentiment.Confused   => "🤔",
            Sentiment.Happy      => "😊",
            _                    => ""
        };

        /// <summary>
        /// Returns a short label for the sentiment badge.
        /// </summary>
        public static string GetLabel(Sentiment sentiment) => sentiment switch
        {
            Sentiment.Worried    => "Feeling worried — extra reassurance mode on",
            Sentiment.Curious    => "Curiosity detected — great mindset for learning!",
            Sentiment.Frustrated => "Frustration detected — let's simplify things",
            Sentiment.Confused   => "Confusion detected — I'll explain more clearly",
            Sentiment.Happy      => "Positive vibes — keep it up!",
            _                    => ""
        };
    }
}
