﻿using System;
using System.Threading;
using System.Speech.Synthesis;

namespace CyberBot
{
    public class Command
    {
        private SpeechSynthesizer speaker = new SpeechSynthesizer();

        public Command()
        {
            speaker.Rate = -2; 
        }

        public void TypeText(string message)
        {
            Console.ForegroundColor = ConsoleColor.Blue;

            // Start speaking at the same time
            Thread speechThread = new Thread(() =>
            {
                speaker.SpeakAsyncCancelAll();
                speaker.Speak(message);
            });

            speechThread.Start();

            
            foreach (char c in message)
            {
                Console.Write(c);

                if (c == ',')
                    Thread.Sleep(600);
                else if (c == '.')
                    Thread.Sleep(1000);
                else
                    Thread.Sleep(50);
            }

            Console.WriteLine();
            Console.ResetColor();
        }

        private void SpeakText(string message)
        {
            speaker.Speak(message);
        }

        public string GetResponse(string input)
        {
            if (input.Contains("how are you"))
                return "I am functioning well, thank you for asking.";

            else if (input.Contains("your purpose"))
                return "My purpose is to educate you about cybersecurity, and help you stay safe online.";

            else if (input.Contains("phishing"))
                return "Phishing is when attackers trick you into revealing personal information, never click suspicious links.";

            else if (input.Contains("password"))
                return "Use strong passwords, combine letters, numbers, and symbols, and never share them.";

            else if (input.Contains("safe browsing"))
                return "Always check website links, avoid unknown downloads, and keep your software updated.";

            else if (input.Contains("scam"))
                return "Online scams often pretend to be trusted sources, always verify before taking action.";

            else
                return "I did not quite understand that, could you please rephrase.";
        }
    }
}
