﻿using System;
using System.Diagnostics;

namespace CyberBot
{
    class Program
    {
        static void Main(string[] args)
        {
            Process bot = new Process();
            bot.StartChat();
        }
    }
}