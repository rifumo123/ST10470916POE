﻿using System;
using System.Threading;

namespace CyberBot
{
    public class Process
    {
        private Command command = new Command();

        public void StartChat()
        {
            Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine(@"
   _____                            ____        _   
  / ____|                          |  _ \      | |  
 | |     ___  _ __  _ __   ___ _ __| |_) | ___ | |_ 
 | |    / _ \| '_ \| '_ \ / _ \ '__|  _ < / _ \| __|
 | |___| (_) | | | | | | |  __/ |  | |_) | (_) | |_ 
  \_____\___/|_| |_|_| |_|\___|_|  |____/ \___/ \__|
");

            Console.WriteLine("=======================================");
            Console.WriteLine("              CONNERBOT");
            Console.WriteLine("=======================================");
            Console.ResetColor();

           
            command.TypeText("Hello, welcome to ConnerBot. I will help you stay safe online.");

            Console.Write("\nEnter your name: ");
            string name = Console.ReadLine();

            command.TypeText($"Hello {name}, how can I assist you today.");

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\nYou: ");
                string input = Console.ReadLine().ToLower();

                if (string.IsNullOrWhiteSpace(input))
                {
                    command.TypeText("Please enter a valid question.");
                    continue;
                }

                if (input == "exit")
                {
                    command.TypeText("Goodbye, stay safe online.");
                    break;
                }

                Thread.Sleep(200); 

                string response = command.GetResponse(input);
                command.TypeText(response);
            }
        }
    }
}