/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tvseriesmangementapplication;

/**
 *
 * @author RC_Student_lab
 */
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class Series {
    private final ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    // Validate age restriction
    private boolean isValidAge(String age) {
        try {
            int ageNum = Integer.parseInt(age);
            return ageNum >= 2 && ageNum <= 18;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Capture new series
    public void CaptureSeries() {
        System.out.println("\nCAPTURE NEW SERIES");
        System.out.println("=================");

        System.out.print("Enter Series ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Series Name: ");
        String name = scanner.nextLine();

        String age;
        do {
            System.out.print("Enter Age Restriction (2-18): ");
            age = scanner.nextLine();
            if (!isValidAge(age)) {
                System.out.println("Invalid age restriction! Please enter a number between 2 and 18.");
            }
        } while (!isValidAge(age));

        System.out.print("Enter Number of Episodes: ");
        String episodes = scanner.nextLine();

        seriesList.add(new SeriesModel(id, name, age, episodes));
        System.out.println("\nSeries details successfully saved!");
    }

    public void SearchSeries() {
        System.out.println("\nSEARCH SERIES");
        System.out.println("=============");
        System.out.print("Enter Series ID to search: ");
        String id = scanner.nextLine();

        boolean found = false;
        for (SeriesModel series : seriesList) {
            if (series.SeriesId.equals(id)) {
                System.out.println("\nSeries Found!");
                System.out.println("ID: " + series.SeriesId);
                System.out.println("Name: " + series.SeriesName);
                System.out.println("Age Restriction: " + series.SeriesAge);
                System.out.println("Number of Episodes: " + series.SeriesNumberOfEpisodes);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("\nError: No series found with ID " + id);
        }
    }
    
    public void UpdateSeries() {
        System.out.println("\nUPDATE SERIES");
        System.out.println("=============");
        System.out.print("Enter Series ID to update: ");
        String id = scanner.nextLine();

        for (SeriesModel series : seriesList) {
            if (series.SeriesId.equals(id)) {
                System.out.print("Enter new Series Name (" + series.SeriesName + "): ");
                String name = scanner.nextLine();
                if (!name.isEmpty()) {
                    series.SeriesName = name;
                }

                String age;
                do {
                    System.out.print("Enter new Age Restriction (" + series.SeriesAge + ") (2-18): ");
                    age = scanner.nextLine();
                    if (!age.isEmpty() && !isValidAge(age)) {
                        System.out.println("Invalid age restriction! Please enter a number between 2 and 18.");
                    }
                } while (!age.isEmpty() && !isValidAge(age));
                if (!age.isEmpty()) {
                    series.SeriesAge = age;
                }

                System.out.print("Enter new Number of Episodes (" + series.SeriesNumberOfEpisodes + "): ");
                String episodes = scanner.nextLine();
                if (!episodes.isEmpty()) {
                    series.SeriesNumberOfEpisodes = episodes;
                }

                System.out.println("\nSeries updated successfully!");
                return;
            }
        }
        System.out.println("\nError: No series found with ID " + id);
    }

    // Delete series
    public void DeleteSeries() {
        System.out.println("\nDELETE SERIES");
        System.out.println("=============");
        System.out.print("Enter Series ID to delete: ");
        String id = scanner.nextLine();

        for (int i = 0; i < seriesList.size(); i++) {
            if (seriesList.get(i).SeriesId.equals(id)) {
                System.out.print("Are you sure you want to delete " + seriesList.get(i).SeriesName + "? (y/n): ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    seriesList.remove(i);
                    System.out.println("\nSeries deleted successfully!");
                } else {
                    System.out.println("\nDeletion cancelled.");
                }
                return;
            }
        }
        System.out.println("\nError: No series found with ID " + id);
    }

    public void SeriesReport() {
        System.out.println("\nSERIES REPORT");
        System.out.println("=============");
        if (seriesList.isEmpty()) {
            System.out.println("No series available.");
            return;
        }

        for (SeriesModel series : seriesList) {
            System.out.println("Series ID: " + series.SeriesId);
            System.out.println("Series Name: " + series.SeriesName);
            System.out.println("Age Restriction: " + series.SeriesAge);
            System.out.println("Number of Episodes: " + series.SeriesNumberOfEpisodes);
            System.out.println("-------------------");
        }
    }

    // Exit application
    public void ExitSeriesApplication() {
        System.out.println("\nThank you for using the Series Management System. Goodbye!");
        System.exit(0);
    }
}

