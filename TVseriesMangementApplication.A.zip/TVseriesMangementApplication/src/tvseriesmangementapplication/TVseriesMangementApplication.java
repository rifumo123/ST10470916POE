/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tvseriesmangementapplication;
import java.util.ArrayList;
import java.util.Scanner;


public class TVseriesMangementApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
Scanner scanner = new Scanner(System.in);
        Series seriesManager = new Series();

        while (true) {
            System.out.println("\nTV SERIES MANAGEMENT SYSTEM");
            System.out.println("==========================");
            System.out.println("1. Capture New Series");
            System.out.println("2. Search Series");
            System.out.println("3. Update Series");
            System.out.println("4. Delete Series");
            System.out.println("5. Series Report");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    seriesManager.CaptureSeries();
                    break;
                case "2":
                    seriesManager.SearchSeries();
                    break;
                case "3":
                    seriesManager.UpdateSeries();
                    break;
                case "4":
                    seriesManager.DeleteSeries();
                    break;
                case "5":
                    seriesManager.SeriesReport();
                    break;
                case "6":
                    seriesManager.ExitSeriesApplication();
                    break;
                default:
                    System.out.println("\nInvalid choice! Please select a number between 1 and 6.");
                 }
            }
}

}