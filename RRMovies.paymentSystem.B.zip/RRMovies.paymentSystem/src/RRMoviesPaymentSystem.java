import java.util.ArrayList;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.ZoneId;

class Entity {
    private final String id;

    public Entity(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
}

class Customer extends Entity {
    private final String name;
    private boolean hasPaid;

    public Customer(String id, String name) {
        super(id);
        this.name = name;
        this.hasPaid = false;
    }

    public String getName() {
        return name;
    }

    public boolean hasPaid() {
        return hasPaid;
    }

    public void setPaid(boolean paid) {
        this.hasPaid = paid;
    }
}

// Series class
class Series {
    private final String seriesId;
    private final String title;
    private final String ageRestriction;
    private final String numberOfEpisodes;
    String getNumberOfEpisodes;

    public Series(String seriesId, String title, String ageRestriction, String numberOfEpisodes) {
        this.seriesId = seriesId;
        this.title = title;
        this.ageRestriction = ageRestriction;
        this.numberOfEpisodes = numberOfEpisodes;
    }

    public String getSeriesId() {
        return seriesId;
    }

    public String getTitle() {
        return title;
    }

    public String getAgeRestriction() {
        return ageRestriction;
    }

    public String getNumberOfEpisodes() {
        return numberOfEpisodes;
    }
}

// PaymentManager class for inheritance
class PaymentManager {
    protected boolean processPayment(double amount) {
        // Simulate payment processing (always succeeds for demo)
        return true;
    }
}

// RR.Movies System class
class RRMoviesSystem extends PaymentManager {
    private final ArrayList<Customer> customers = new ArrayList<>();
    private final ArrayList<Series> seriesList = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    // Constructor with sample series
    public RRMoviesSystem() {
        seriesList.add(new Series("S001", "Action Movie", "12", "10"));
        seriesList.add(new Series("S002", "Comedy Series", "7", "8"));
    }

    // Register a new customer
    public void registerCustomer() {
        System.out.println("\nREGISTER CUSTOMER");
        System.out.println("================");
        System.out.print("Enter Customer ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Customer Name: ");
        String name = scanner.nextLine();
        customers.add(new Customer(id, name));
        System.out.println("\nCustomer registered successfully!");
    }

    // Process payment
    public void processPayment() {
        System.out.println("\nPROCESS PAYMENT");
        System.out.println("==============");
        System.out.print("Enter Customer ID: ");
        String id = scanner.nextLine();
        for (Customer customer : customers) {
            if (customer.getId().equals(id)) {
                customer.setPaid(processPayment(99.99)); // R99.99 fee
                System.out.println("\nPayment processed for " + customer.getName() + ". Status: " + (customer.hasPaid() ? "Paid" : "Unpaid"));
                return;
            }
        }
        System.out.println("\nCustomer not found!");
    }

    // Watch series
    public void watchSeries() {
        System.out.println("\nWATCH SERIES");
        System.out.println("===========");
        System.out.print("Enter Customer ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Series ID: ");
        String seriesId = scanner.nextLine();

        Customer customer = null;
        for (Customer c : customers) {
            if (c.getId().equals(id)) {
                customer = c;
                break;
            }
        }
        if (customer == null) {
            System.out.println("\nCustomer not found!");
            return;
        }

        Series series = null;
        for (Series s : seriesList) {
            if (s.getSeriesId().equals(seriesId)) {
                series = s;
                break;
            }
        }
        if (series == null) {
            System.out.println("\nSeries not found!");
            return;
        }

        if (customer.hasPaid()) {
            System.out.println("\nWatching " + series.getTitle() + " (Age: " + series.getAgeRestriction() + ", Episodes: " + series.getNumberOfEpisodes + ")");
        } else {
            System.out.println("\nPlease pay R99.99 to watch " + series.getTitle());
        }
    }

    // Generate report
    public void generateReport() {
        System.out.println("\nRR.MOVIES PAYMENT REPORT - " + LocalDateTime.now(ZoneId.of("Africa/Johannesburg")).withHour(10).withMinute(3).withSecond(0));
        System.out.println("==================================");
        if (customers.isEmpty()) {
            System.out.println("No customers registered.");
            return;
        }
        for (Customer customer : customers) {
            System.out.println("Customer ID: " + customer.getId());
            System.out.println("Name: " + customer.getName());
            System.out.println("Payment Status: " + (customer.hasPaid() ? "Paid (R99.99)" : "Unpaid"));
            System.out.println("-------------------");
        }
        System.out.println("Total Series Available: " + seriesList.size());
    }

    // Exit application
    public void exitApplication() {
        System.out.println("\nThank you for using RR.Movies. Goodbye!");
        System.exit(0);
    }
}

// Main class
public class RRMoviesPaymentSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RRMoviesSystem rrmovies = new RRMoviesSystem();

        while (true) {
            System.out.println("\nRR.MOVIES PAYMENT SYSTEM");
            System.out.println("=======================");
            System.out.println("1. Register Customer");
            System.out.println("2. Process Payment");
            System.out.println("3. Watch Series");
            System.out.println("4. Generate Report");
            System.out.println("5. Exit");
            System.out.print("Enter your choice (1-5): ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> rrmovies.registerCustomer();
                case "2" -> rrmovies.processPayment();
                case "3" -> rrmovies.watchSeries();
                case "4" -> rrmovies.generateReport();
                case "5" -> rrmovies.exitApplication();
                default -> System.out.println("\nInvalid choice! Please select a number between 1 and 5.");
            }
        }
    }
}

