/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class RRMoviesSystemTest {
    
    public RRMoviesSystemTest() {
    }

    @Test
    public void testRegisterCustomer() {
    }

    @Test
    public void testProcessPayment() {
    }

    @Test
    public void testWatchSeries() {
    }

    @Test
    public void testGenerateReport() {
    }

    @Test
    public void testExitApplication() {
    }
    
}
