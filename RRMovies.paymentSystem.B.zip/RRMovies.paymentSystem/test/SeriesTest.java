/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class SeriesTest {
    
    public SeriesTest() {
    }

    @Test
    public void testGetSeriesId() {
    }

    @Test
    public void testGetTitle() {
    }

    @Test
    public void testGetAgeRestriction() {
    }

    @Test
    public void testGetNumberOfEpisodes() {
    }
    
}
