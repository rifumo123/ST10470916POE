using System;
using System.Windows.Forms;
using System.Runtime.Versioning;

namespace CyberBot
{
    static class Program
    {
        [SupportedOSPlatform("windows6.1")]
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}