﻿
namespace CyberBot
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnViewTask = new Button();
            btnQuiz = new Button();
            btnSend = new Button();
            btnAddTask = new Button();
            btnLog = new Button();
            rbtChat = new RichTextBox();
            txtInput = new TextBox();
            SuspendLayout();
            // 
            // btnViewTask
            // 
            btnViewTask.Location = new Point(406, 321);
            btnViewTask.Name = "btnViewTask";
            btnViewTask.Size = new Size(94, 29);
            btnViewTask.TabIndex = 0;
            btnViewTask.Text = "View Task";
            btnViewTask.UseVisualStyleBackColor = true;
            btnViewTask.Click += BtnViewTask_Click;
            // 
            // btnQuiz
            // 
            btnQuiz.Location = new Point(162, 321);
            btnQuiz.Name = "btnQuiz";
            btnQuiz.Size = new Size(94, 29);
            btnQuiz.TabIndex = 1;
            btnQuiz.Text = "StartQuiz";
            btnQuiz.UseVisualStyleBackColor = true;
            btnQuiz.Click += BtnQuiz_Click;
            // 
            // btnSend
            // 
            btnSend.Location = new Point(349, 235);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(94, 29);
            btnSend.TabIndex = 2;
            btnSend.Text = "Send";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSend_Click;
            // 
            // btnAddTask
            // 
            btnAddTask.Location = new Point(280, 321);
            btnAddTask.Name = "btnAddTask";
            btnAddTask.Size = new Size(94, 29);
            btnAddTask.TabIndex = 3;
            btnAddTask.Text = "AddTask";
            btnAddTask.UseVisualStyleBackColor = true;
            btnAddTask.Click += BtnAddTask_Click;
            // 
            // btnLog
            // 
            btnLog.Location = new Point(533, 321);
            btnLog.Name = "btnLog";
            btnLog.Size = new Size(94, 29);
            btnLog.TabIndex = 4;
            btnLog.Text = "ActivityLog";
            btnLog.UseVisualStyleBackColor = true;
            btnLog.Click += BtnLog_Click;
            // 
            // rbtChat
            // 
            rbtChat.Location = new Point(231, 56);
            rbtChat.Name = "rbtChat";
            rbtChat.ReadOnly = true;
            rbtChat.Size = new Size(125, 120);
            rbtChat.TabIndex = 5;
            rbtChat.Text = "";
            rbtChat.TextChanged += RbtChat_TextChanged;
            // 
            // txtInput
            // 
            txtInput.Location = new Point(178, 235);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(125, 27);
            txtInput.TabIndex = 6;
            txtInput.TextChanged += txtInput_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtInput);
            Controls.Add(rbtChat);
            Controls.Add(btnLog);
            Controls.Add(btnAddTask);
            Controls.Add(btnSend);
            Controls.Add(btnQuiz);
            Controls.Add(btnViewTask);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        private void RbtChat_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Button btnViewTask;
        private Button btnQuiz;
        private Button btnSend;
        private Button btnAddTask;
        private Button btnLog;
        private RichTextBox rbtChat;
        private TextBox txtInput;
    }
}
