﻿namespace CyberBot
{
    public class TaskItem
    {
        public int Id { get; set; }
        public required string Title { get; set; }
        public required string Description { get; set; }
        public required string ReminderDate { get; set; }
        public bool Completed { get; set; }
    }
}