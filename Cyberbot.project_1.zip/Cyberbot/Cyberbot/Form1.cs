namespace CyberBot
{
   
    public partial class Form1 : Form
    {
        List<QuizQuestion> quiz = new List<QuizQuestion>();
        private RichTextBox? rtbChat;

        public Form1(RichTextBox? rtbChat)
        {
            this.rtbChat = rtbChat;
        }

        private int current;
        private string score = string.Empty;
        private object activityLog = new object();

        void LoadQuiz()
        {
            quiz.Add(new QuizQuestion()
            {
                Question = "What is phishing?",
                Answer = "a",
                Explanation = "Fake emails trying to steal info"
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "True or False: Password sharing is safe.",
                Answer = "false",
                Explanation = "Never share passwords"
            });
            quiz.Add(new QuizQuestion()
            {
                Question = "What is phishing?",
                Answer = "a",
                Explanation = "Phishing is a scam where attackers trick users into revealing personal information."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "True or False: Sharing your password is safe.",
                Answer = "false",
                Explanation = "Passwords should never be shared with anyone."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "What should you do if you receive a suspicious email?",
                Answer = "c",
                Explanation = "You should report or delete suspicious emails to stay safe."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "What does 2FA stand for?",
                Answer = "two factor authentication",
                Explanation = "2FA adds an extra layer of security when logging in."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "Which is a strong password?",
                Answer = "b",
                Explanation = "Strong passwords include letters, numbers, and symbols."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "True or False: Antivirus software protects your computer.",
                Answer = "true",
                Explanation = "Antivirus software helps detect and remove malware."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "What is malware?",
                Answer = "b",
                Explanation = "Malware is harmful software designed to damage systems."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "What is a firewall used for?",
                Answer = "a",
                Explanation = "A firewall protects your network from unauthorized access."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "True or False: Public Wi-Fi is always safe.",
                Answer = "false",
                Explanation = "Public Wi-Fi can be unsafe without protection like VPN."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "What is social engineering?",
                Answer = "c",
                Explanation = "Social engineering manipulates people into giving information."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "What should you do before clicking a link?",
                Answer = "b",
                Explanation = "Always check if the link is safe and from a trusted source."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "True or False: You should update your software regularly.",
                Answer = "true",
                Explanation = "Updates fix security vulnerabilities."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "What is a safe browsing habit?",
                Answer = "a",
                Explanation = "Avoid downloading unknown files and check website security."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "What does VPN stand for?",
                Answer = "virtual private network",
                Explanation = "A VPN protects your internet connection and privacy."
            });

            quiz.Add(new QuizQuestion()
            {
                Question = "True or False: Clicking unknown links is safe.",
                Answer = "false",
                Explanation = "Unknown links may contain viruses or scams."
            });
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void rbtChat_TextChanged(object sender, EventArgs e)
        {

        }

            private string GetResponse(string input)
        {
            if (input.Contains("password"))
                return "Use strong passwords with numbers and symbols.";

            if (input.Contains("phishing"))
                return "Never click suspicious links.";

            if (input.Contains("2fa"))
                return "Two-factor authentication adds extra security.";

            if (input.Contains("malware"))
                return "Malware is harmful software that damages systems.";

            return "I did not understand. Try asking differently.";
        }
        

        private void txtInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSend_Click(object sender, EventArgs e)
        {

        }

        private void BtnQuiz_Click(object sender, EventArgs e)
        {
            LoadQuiz();
            StartQuiz();
        }

        private void StartQuiz()
        {
            throw new NotImplementedException();
        }

        private void BtnAddTask_Click(object sender, EventArgs e)
        {

        }
        private void BtnViewTask_Click(object sender, EventArgs e)
        {

        }

        private void BtnLog_Click(object sender, EventArgs e)
        {


        }
    }
}
