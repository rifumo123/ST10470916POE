﻿namespace Cyberbot
{
    public class Window
    {
    }
}