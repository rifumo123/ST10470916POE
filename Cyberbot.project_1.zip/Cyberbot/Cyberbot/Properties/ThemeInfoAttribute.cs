﻿
internal class ThemeInfoAttribute : Attribute
{
}