﻿
namespace CyberBot.Properties;

public enum ResourceDictionaryLocation
{
    None = 0,
    SourceAssembly = 1,
    ExternalAssembly = 2
}
