﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;


[assembly: AssemblyTitle("Cyberbot")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Cyberbot")]
[assembly: AssemblyCopyright("Copyright ©  2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace CyberBot.Properties;

[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = false)]
public sealed class ThemeInfoAttribute : Attribute
{
    public int ThemeDictionaryLocation { get; }
    public int GenericDictionaryLocation { get; }

    public ThemeInfoAttribute(int themeDictionaryLocation, int genericDictionaryLocation)
    {
        ThemeDictionaryLocation = themeDictionaryLocation;
        GenericDictionaryLocation = genericDictionaryLocation;
    }
}