﻿// This file is a duplicate definition of ResourceDictionaryLocation.
// To fix CS0101, remove this file or rename the class if both are needed with different purposes.
// If you intend to keep only one definition, delete this file.

// FIX: Remove this duplicate file to resolve CS0101.