﻿using MySql.Data.MySqlClient;

namespace CyberBot
{
    public class DatabaseHelper
    {
        private const string V = "server=localhost;uid=root;pwd=YOUR_PASSWORD;database=CyberBotDB;";
        private string conn =
        V;

        public void AddTask(string title, string desc)
        {
            using (MySqlConnection con = new MySqlConnection(conn))
            {
                con.Open();

                string query =
                "INSERT INTO Tasks(Title,Description,Completed) VALUES(@t,@d,0)";

                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@t", title);
                cmd.Parameters.AddWithValue("@d", desc);

                cmd.ExecuteNonQuery();
            }
        }
    }
}