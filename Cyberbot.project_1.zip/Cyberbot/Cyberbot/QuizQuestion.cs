﻿namespace CyberBot
{
    public class QuizQuestion
    {
        public required string Question { get; set; }
        public required string Answer { get; set; }
        public required string Explanation { get; set; }
    }
}
